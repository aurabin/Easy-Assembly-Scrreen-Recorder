# Quellcodedokumentation

## Build-Einstieg

`make easy` prüft SDK und Werkzeuge und ruft die beiden Plattform-Builds auf. Details zur Einrichtung stehen im [README](README.md).

## Einstieg und Bildschirmaufnahme

| Datei | Aufgabe |
| --- | --- |
| EasyScreenRecorder.s | 68k-Shell-Einstieg, Bibliotheken öffnen, Argumente lesen, Bildschirm erfassen, Dateiausgabe und Aufräumen |
| EasyScreenRecorder-AROS-x86_64.c | C-Implementierung derselben Pipeline für AROS ABI v11 |
| EasyScreenRecorder-AROS-x86_64.cpp | C++-Implementierung mit einem `ImageBuffer`, der den RGB-Puffer beim Verlassen der Funktion freigibt |
| image_writer.c | Endung erkennen, Bildformat auswählen, RGB-Puffer kodieren und Ausgabe-Callbacks an die Plattform weiterreichen |
| image_writer-040.s / image_writer-060.s | Generierte GNU-m68k-Assemblerquellen für den Encoder und seine freistehenden Speicherfunktionen |
| mp4_writer.inc | Motion-JPEG-Frames schreiben und MP4-Metadaten erzeugen |
| freestanding/ | Minimale C-Header für den Build ohne Standardbibliothek des Hostsystems |
| stb_image_write.h | Eingebundener BMP-, JPEG- und PNG-Encoder mit eigener Lizenz und einer Korrektur zur Freigabe des PNG-Puffers bei Speicherknappheit |

Die Shell liefert `FILE/A` über `dos.library/ReadArgs`. `image_format` ignoriert die Groß-/Kleinschreibung und gibt 1 für BMP, 2 für JPEG, 3 für PNG, 4 für MP4 und 0 bei unbekannter Endung zurück. Nach der Wartezeit von 150 DOS-Ticks sperrt `LockPubScreen` den Workbench-Bildschirm beziehungsweise unter AROS den Standardbildschirm. Die Sperre hält das Bildschirmobjekt gültig. Während der Aufnahme können sich Bildschirminhalte ändern.

Bei indizierten Modi liefert `ReadPixel` die Farbnummer. `GetRGB32` stellt die Palette bereit. Für True Color verwendet der 68k-Code `ReadRGBPixel` und zerlegt AARRGGBB in RGB. Die x86-64-Varianten verwenden `ReadPixelArray` mit `RECTFMT_RGB` zeilenweise. Der Encoder erhält den Puffer in Zeilenreihenfolge von oben nach unten mit drei Bytes pro Pixel.

Die 68k-Routinen `rec_alloc`, `rec_free` und `rec_write` verbinden den GCC-m68k-Aufrufstandard mit Exec und DOS. Auf x86-64 verwenden die gleichnamigen Funktionen die SDK-Bibliotheksmakros. Die Bildencoder laufen ohne eine C-Laufzeitbibliothek des Zielsystems. Das Programm prüft vor dem Öffnen, ob der Zielname bereits existiert. Der Schreibcallback erkennt unvollständige Schreibvorgänge. Der Fehlerpfad schließt die Datei, entfernt eine angelegte Teildatei, gibt den Bildpuffer frei, entsperrt den Bildschirm und schließt die Bibliotheken. Erfolgsstatus ist 0, Fehlerstatus 20.

## Videoencoder und MP4-Muxer

Bei Endung `.mp4` öffnet das Programm eine neue Datei. `video_begin` schreibt die Container-Kennung `ftyp` und einen Platzhalter für die Größe des Medienblocks `mdat`. Die Plattformschleife wartet auf Record und erfasst bis zum berechneten Limit. Stop oder Schließen wird zwischen den Bildern ausgewertet. `video_frame` kodiert den RGB-Puffer jeweils als JPEG mit Qualitätsstufe 75. Ein 4096-Byte-Puffer bündelt die kleinen Schreibaufrufe. Die Frame-Größen werden für den MP4-Index gespeichert. Der Code begrenzt den Medienblock auf weniger als 2 GiB und wächst den Frame-Index dynamisch. 

`video_finish` korrigiert die Größe von `mdat` über den plattformspezifischen DOS-Seek-Callback `rec_seek`. Anschließend schreibt es den `moov`-Block mit einem Videotrack, einem gemeinsamen Daten-Chunk, einer Frame-Größentabelle und konstantem Zeitraster. Der Sample-Eintrag `mp4v` enthält den MPEG-4-Systems-Objekttyp 0x6C für JPEG. Die Datei benötigt ein seek-fähiges Ziel und einen Player mit Unterstützung für dieses Format. Ein Schreib- oder Seek-Fehler führt zum normalen Fehlerpfad, der die Teildatei entfernt. Es gibt keine Audiospur.

## Zuordnung zum Windows-MP4-Code

| Windows | Amiga und AROS |
| --- | --- |
| capture_display / BitBlt | 68k-Pixelschleife oder AROS ReadPixelArray |
| record_tick / GetTickCount64 | Feste Frameanzahl mit DOS-Delay zwischen Bildern |
| convert_nv12 | RGB-Puffer wird direkt an den JPEG-Encoder übergeben |
| prepare_writer / MFCreateSinkWriterFromURL | video_begin und eigener MP4-Muxer |
| write_sample | video_frame schreibt ein JPEG und vermerkt seine Größe |
| finish_recording / Finalize | video_finish ergänzt die Container-Metadaten und den Index |

Die Windows-Referenz kodiert H.264 über Media Foundation. Auf den Zielsystemen werden die Video- und Bildmodule statisch eingebunden. Die 68k-Programme werden aus Motorola-Assembler und den generierten GNU-Assemblerquellen gebaut. Die x86-64-Varianten verlinken das gemeinsame C-Modul mit dem jeweiligen C- oder C++-Frontend.

## Korrekturen aus der Build-Prüfung

Die JPEG-Arbeitsfelder für die Blocktransformation liegen im statischen Speicher des jeweiligen Programms. Das reduziert den Stackbedarf von JPG und MP4. Der gemeinsame Encoder ist auf einen Aufruf zur Zeit pro Prozess ausgelegt. Die Farbtiefe wird über GetBitMapAttr gelesen. Dateien werden nur angelegt, wenn DOS den Zielnamen als nicht vorhanden meldet.

Der Zielpfad wird über DOS Lock und Info auf sein Volume abgebildet. Das angezeigte Limit basiert auf 85 % der konservativ geschätzten Bildanzahl. Der Index wächst bei Bedarf und wird beim Abschließen blockweise geschrieben. Wenn ein Frame nur teilweise geschrieben wird, versucht der Recorder, die Datei auf das letzte vollständige Bild zurückzusetzen und den Clip abzuschließen. Schlägt das fehl, greift der normale Fehlerpfad für Teildateien.
