#!/bin/sh
set -eu
sdk=${1:?Pass the AROS ABI v11 SDK Development directory}
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
flags="-O2 -ffreestanding -fno-stack-protector -fno-asynchronous-unwind-tables -fno-pic -mcmodel=large -mno-red-zone"
cc $flags -I freestanding -c image_writer.c -o "$tmp/writer.o"
cc $flags -D__AROS__ -D__AROS64__ -I"$sdk/include" -Wall -Wextra -Werror \
    -c EasyScreenRecorder-AROS-x86_64.c -o "$tmp/c.o"
c++ $flags -U_GNU_SOURCE -fno-exceptions -fno-rtti -D__AROS__ -D__AROS64__ -I"$sdk/include" -Wall -Wextra -Werror \
    -c EasyScreenRecorder-AROS-x86_64.cpp -o "$tmp/cpp.o"
printf '%s\n' 'SECTIONS { .text : { *(.text.entry) *(.text .text.*) } }' > "$tmp/entry.ld"
for language in c cpp; do
    name=EasyScreenRecorder-AROS-x86_64-$language
    ld -r -T "$tmp/entry.ld" -o "$name" "$tmp/$language.o" "$tmp/writer.o"
    test -z "$(nm -u "$name")"
    python3 - "$name" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
image = bytearray(path.read_bytes())
assert image[:7] == b"\x7fELF\x02\x01\x01"
image[7:9] = bytes([15, 11])  # AROS, ABI v11
path.write_bytes(image)
PY
    chmod +x "$name"
done
