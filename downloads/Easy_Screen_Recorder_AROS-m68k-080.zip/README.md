# Easy Screen Recorder für Amiga und AROS

Die Shell-Anwendung erfasst den öffentlichen Bildschirm nach etwa drei Sekunden Vorlauf. Die Dateiendung bestimmt das Ausgabeformat. `.bmp`, `.jpg`, `.jpeg` und `.png` speichern ein Standbild. `.mp4` öffnet ein Fenster mit Record und Stop und speichert Bilder bis zum berechneten Limit als Motion-JPEG-Video ohne Ton.

| Programmdatei | Zielsystem | Quellsprache des Builds |
| --- | --- | --- |
| EasyScreenRecorder-AmigaOS39-040 | AmigaOS 3.9, 68040 | Motorola-Assembler |
| EasyScreenRecorder-AmigaOS39-060 | AmigaOS 3.9, 68060 | Motorola-Assembler |
| EasyScreenRecorder-Apollo-Vampire-080 | Apollo Vampire, 68080 | Motorola-Assembler |
| EasyScreenRecorder-AROS-m68k-080 | AROS/m68k, 68080 mit Hunk-Loader | Motorola-Assembler |
| EasyScreenRecorder-AROS-x86_64-c | AROS x86-64, ABI v11 | C |
| EasyScreenRecorder-AROS-x86_64-cpp | AROS x86-64, ABI v11 | C++ mit gemeinsamem C-Bildencoder |

In der Amiga-Shell das passende Programm mit einem neuen Dateinamen starten.

```text
EasyScreenRecorder-Apollo-Vampire-080 RAM:Screen.mp4
EasyScreenRecorder-AROS-m68k-080 RAM:Screen.jpg
EasyScreenRecorder-AROS-x86_64-cpp RAM:Screen.bmp
```

Falls der Entpacker das Ausführungsbit entfernt, setze es mit `Protect PROGRAMMNAME +e`. Unterstützt werden indizierte Modi bis 256 Farben sowie True Color mit kompatibler CyberGraphX-Bibliothek. HAM und Extra Half-Brite werden abgewiesen. Die maximale Bildgröße beträgt 4096 × 4096. Der Hardware-Mauszeiger wird beim Auslesen des Bildschirm-Bitmaps nicht erfasst. JPEG verwendet Qualitätsstufe 90. PNG ist verlustfrei und verwendet unkomprimierte DEFLATE-Blöcke.

Im MP4-Bedienfenster startet Enter die Aufnahme und Space beendet sie. Das Fenster muss dafür den Tastaturfokus haben. Die Tasten stehen unter den jeweiligen Buttons.

## Alle sechs Varianten bauen

Im entpackten Verzeichnis unter x86-64-Linux:

```sh
make easy AROS_SDK=/pfad/zum/SDK-202609/Development
```

Liegt `SDK-202609/Development` direkt im Projektordner, genügt `make easy`.
Vorausgesetzt werden GNU Make und die unten aufgeführten Werkzeuge. Das Ziel baut die vier 68k-Programme und beide AROS-x86-64-Programme im Projektordner neu. Bildencoder, Motion-JPEG-Encoder und MP4-Muxer werden direkt eingebunden.

Für einen einzelnen Zieltyp gibt es `make amiga` und `make aros-x86_64 AROS_SDK=/pfad/zum/Development`. Wenn du `image_writer.c` oder `mp4_writer.inc` änderst, erzeuge vor dem 68k-Build mit `make regenerate-m68k-encoder` die beiden Assemblerdateien neu.

## Build-Werkzeuge

**68k.** Auf Linux im entpackten Verzeichnis `sh build-m68k.sh` ausführen. Das Skript benötigt vasm mit Motorola-Syntax, GNU `m68k-linux-gnu-as` und vlink im Suchpfad. Die Variablen `VASM`, `M68K_AS` und `VLINK` können auf abweichende Installationspfade zeigen. Das Skript assembliert die mitgelieferten Quellen und verknüpft sie zu Amiga-Hunk-Dateien. Das JPEG-Verfahren verwendet FPU-Instruktionen. Die 080-Varianten übernehmen den 060-Encoder und setzen eine entsprechend kompatible FPU voraus.

Die Assemblerquellen `image_writer-040.s` und `image_writer-060.s` wurden mit GCC 12 aus `image_writer.c` erzeugt. Für Änderungen am Encoder lässt sich der Assemblercode mit `sh regenerate-m68k-encoder.sh` neu erzeugen. `M68K_CC` kann auf den gewünschten GNU-Cross-Compiler zeigen. Die regulären 68k-Builds verwenden die enthaltenen Assemblerquellen direkt.

**AROS x86-64.** Auf x86-64-Linux den ABI-v11-SDK-Ordner angeben.

```sh
sh build-aros-x86_64.sh /pfad/zu/SDK-202609/Development
```

Das Skript benötigt GNU C/C++, GNU ld, nm und Python 3. Es erstellt zwei relocatable ELF-Programme mit der AROS-ABI-v11-Kennung. Die AROS-Varianten in diesem Paket zielen auf x86-64 und m68k.

## Quellcode und MP4

[QUELLCODE.md](QUELLCODE.md) beschreibt Einstiegspunkte, Datenfluss, Ressourcenverwaltung und die Zuordnung zum Windows-MP4-Code. Die vollständige Windows-Assemblerreferenz liegt unter [reference/Windows-screen_mp4.s](reference/Windows-screen_mp4.s). Die sechs Programme enthalten einen eigenen Motion-JPEG-Encoder und MP4-Muxer. Die Datei ist mit 5 Bildern pro Sekunde  gekennzeichnet. Stop oder das Schließen des Fensters beendet die Aufnahme und schreibt den MP4-Index. Vor Record kann Stop den Vorgang abbrechen. Das Bedienfenster bleibt während der Aufnahme sichtbar. Unten rechts zeigt es `Max. safe est.` als geschätzte MP4-Wiedergabedauer an. Der Recorder fragt den freien Platz des Zielvolumes beim Öffnen und erneut bei Record ab. Aus Auflösung und konservativ geschätzter JPEG-Größe berechnet er die mögliche Bildanzahl und zieht 15 % ab. Die feste 300-Bilder-Grenze entfällt. Ist der freie Platz unbekannt oder reicht er für kein Bild, startet die MP4-Aufnahme nicht. Der Dateigrößenrahmen bleibt wegen der klassischen DOS-Dateioffsets unter 2 GiB. Freier Platz kann sich während einer Aufnahme ändern. Zwischen den Bildern wartet die Aufnahme zehn DOS-Ticks zusätzlich zur Zeit für Bildschirmzugriff, JPEG-Kodierung und Dateiausgabe. Auf langsamer Hardware kann die reale Aufnahme daher länger dauern und bei der Wiedergabe schneller erscheinen. Für Motion JPEG im MP4-Container ist ein passender Player erforderlich, etwa FFplay. Die Windows-Referenz verwendet H.264.

Der gemeinsame Encoder erzeugte auf Linux lesbare BMP-, JPG- und PNG-Dateien. BMP und PNG wurden pixelgenau mit der RGB-Eingabe verglichen. Eine MP4-Testsequenz wurde mit FFmpeg vollständig dekodiert. Alle sechs Programme wurden gebaut und auf ihr Binärformat geprüft. Ein Laufzeittest auf AmigaOS, Vampire und AROS steht aus.

Projektlizenz: [MIT](LICENSE). Die Lizenz des Bildencoders steht am Ende von [stb_image_write.h](stb_image_write.h).
