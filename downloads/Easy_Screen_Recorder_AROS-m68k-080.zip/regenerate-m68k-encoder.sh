#!/bin/sh
set -eu
compiler=${M68K_CC:-m68k-linux-gnu-gcc}
for cpu in 040 060; do
    "$compiler" -S -m68"$cpu" -O2 -ffreestanding -fno-pic \
        -fno-asynchronous-unwind-tables -I freestanding \
        image_writer.c -o "image_writer-$cpu.s"
done
