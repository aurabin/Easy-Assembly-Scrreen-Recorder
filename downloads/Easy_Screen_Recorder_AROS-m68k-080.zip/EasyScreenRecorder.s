; Native Amiga Shell screen grabber. DOS ReadArgs: FILE/A
; Supports indexed non-HAM/EHB and CyberGraphX true-color screens.
    section code,code
    xref image_format,encode_image,video_begin,video_frame,video_finish
    xref video_estimate,video_destination,video_space,video_release
    xdef rec_alloc,rec_free,rec_write,rec_seek,rec_volume,rec_truncate
    movem.l d2-d7/a2-a6,-(sp)
    move.l 4.w,a6
    lea dosname(pc),a1
    moveq #39,d0
    jsr -552(a6)
    move.l d0,dosbase
    beq no_cli
    move.l d0,a6
    jsr -492(a6)                 ; Cli()
    tst.l d0
    beq cleanup_no_cli
    move.l 4.w,a6
    lea intname(pc),a1
    moveq #39,d0
    jsr -552(a6)
    move.l d0,intbase
    beq failed
    lea gfxname(pc),a1
    moveq #39,d0
    jsr -552(a6)
    move.l d0,gfxbase
    beq failed
    move.l dosbase,a6
    lea template(pc),a0
    move.l a0,d1
    lea filename,a0
    move.l a0,d2
    moveq #0,d3
    jsr -798(a6)                 ; ReadArgs
    move.l d0,args
    beq failed
    move.l filename,-(sp)
    jsr image_format
    addq.l #4,sp
    move.l d0,format
    beq failed

    move.l dosbase,a6
    move.l #150,d1
    jsr -198(a6)                 ; 3 second capture delay
    move.l intbase,a6
    ifd AROS68K
    suba.l a0,a0
    else
    lea wbname(pc),a0
    endc
    jsr -510(a6)                 ; LockPubScreen
    move.l d0,screen
    beq failed
    move.l d0,a5
    moveq #0,d6
    move.w 12(a5),d6
    moveq #0,d7
    move.w 14(a5),d7
    tst.w d6
    ble failed
    tst.w d7
    ble failed
    cmp.w #4096,d6
    bhi failed
    move.l 88(a5),a0              ; RastPort.BitMap
    move.l a0,d0
    beq failed
    move.l gfxbase,a6
    moveq #4,d1                   ; BMA_DEPTH
    jsr -960(a6)                  ; GetBitMapAttr
    tst.l d0
    beq failed
    cmp.l #8,d0
    bls indexed
    move.l 4.w,a6
    lea cgxname(pc),a1
    moveq #0,d0
    jsr -552(a6)
    move.l d0,cgxbase
    beq failed
    bra dimensions_ready
indexed:
    move.l gfxbase,a6
    lea 44(a5),a0
    jsr -792(a6)                 ; GetVPModeID
    cmp.l #-1,d0
    beq failed
    and.l #$880,d0               ; HAM and Extra Half-Brite
    bne failed
    move.l 48(a5),a0             ; ViewPort.ColorMap
    move.l a0,d0
    beq failed
    moveq #0,d1
    move.w 2(a0),d1              ; ColorMap.Count
    beq failed
    cmp.w #256,d1
    bhi failed
    move.w d1,palcount
    moveq #0,d0
    lea palette,a1
    jsr -900(a6)                 ; GetRGB32

dimensions_ready:
    cmp.w #4096,d7
    bhi failed
    move.l d6,d0
    mulu.w d7,d0
    move.l d0,d1
    add.l d0,d0
    add.l d1,d0
    move.l d0,-(sp)
    bsr rec_alloc
    addq.l #4,sp
    move.l d0,pixels
    beq failed
    move.l d0,a2

    cmp.l #4,format
    bne check_output
    bsr update_budget
    bsr open_controls
    tst.l d0
    beq failed
    bsr draw_capacity
wait_record:
    move.l controls_port,a0
    move.l 4.w,a6
    jsr -384(a6)                 ; WaitPort
    bsr control_event
    cmp.l #1,d0
    beq start_with_budget
    cmp.l #2,d0
    bne wait_record
    moveq #0,d7
    bra cleanup
start_with_budget:
    bsr update_budget
    bsr draw_capacity
check_output:
    move.l dosbase,a6
    move.l filename,d1
    moveq #-2,d2
    jsr -84(a6)                  ; Lock existing destination
    tst.l d0
    beq check_destination
    move.l d0,d1
    jsr -90(a6)
    bra failed
check_destination:
    jsr -132(a6)                  ; IoErr
    cmp.l #205,d0                 ; ERROR_OBJECT_NOT_FOUND
    bne failed
open_new:
    move.l filename,d1
    move.l #1006,d2              ; MODE_NEWFILE
    jsr -30(a6)
    move.l d0,handle
    beq failed
    st created
    cmp.l #4,format
    bne capture_frame
    move.l d7,-(sp)
    move.l d6,-(sp)
    move.l budget,-(sp)
    jsr video_begin
    lea 12(sp),sp
    tst.l d0
    beq failed
capture_frame:
    move.l pixels,a2
    moveq #0,d5
row:
    moveq #0,d4
pixel:
    move.l cgxbase,d0
    beq indexed_pixel
    move.l d0,a6
    lea 84(a5),a1
    move.l d4,d0
    move.l d5,d1
    jsr -108(a6)                 ; ReadRGBPixel, AARRGGBB
    move.b d0,2(a2)
    ror.l #8,d0
    move.b d0,1(a2)
    ror.l #8,d0
    move.b d0,(a2)
    addq.l #3,a2
    bra pixel_done
indexed_pixel:
    move.l gfxbase,a6
    lea 84(a5),a1
    move.l d4,d0
    move.l d5,d1
    jsr -318(a6)                 ; ReadPixel
    tst.l d0
    bmi failed
    cmp.w palcount,d0
    bhs failed
    mulu #12,d0
    lea palette,a0
    adda.l d0,a0
    move.b (a0),(a2)+
    move.b 4(a0),(a2)+
    move.b 8(a0),(a2)+
pixel_done:
    addq.w #1,d4
    cmp.w d6,d4
    blo pixel
    addq.w #1,d5
    cmp.w d7,d5
    blo row

    cmp.l #4,format
    beq capture_video
    bsr unlock_screen
    move.l format,-(sp)
    move.l d7,-(sp)
    move.l d6,-(sp)
    move.l pixels,-(sp)
    jsr encode_image
    lea 16(sp),sp
    tst.l d0
    beq failed
    bra close_output
capture_video:
    move.l d7,-(sp)
    move.l d6,-(sp)
    move.l pixels,-(sp)
    jsr video_frame
    lea 12(sp),sp
    tst.l d0
    beq failed
    cmp.l #2,d0
    beq finish_video
    move.l dosbase,a6
    moveq #10,d1
    jsr -198(a6)                 ; Delay between captures
    bsr control_event
    cmp.l #2,d0
    bne capture_frame
finish_video:
    bsr unlock_screen
    move.l d7,-(sp)
    move.l d6,-(sp)
    jsr video_finish
    addq.l #8,sp
    tst.l d0
    beq failed
close_output:
    move.l dosbase,a6
    move.l handle,d1
    clr.l handle
    jsr -36(a6)
    tst.l d0
    beq failed
    moveq #0,d7
    bra cleanup
failed:
    moveq #20,d7
    move.l dosbase,a6
    lea error(pc),a0
    move.l a0,d1
    jsr -948(a6)
    bra cleanup
cleanup_no_cli:
    moveq #20,d7
cleanup:
    jsr video_release
    move.l pixels,-(sp)
    bsr rec_free
    addq.l #4,sp
    move.l dosbase,a6
    move.l handle,d1
    beq remove_partial
    jsr -36(a6)
remove_partial:
    tst.l d7
    beq free_args
    tst.b created
    beq free_args
    move.l filename,d1
    jsr -72(a6)                  ; DeleteFile
free_args:
    move.l args,d1
    beq unlock
    jsr -858(a6)
unlock:
    bsr unlock_screen
    bra libraries
unlock_screen:
    move.l controls,d0
    beq unlock_public
    clr.l controls
    move.l d0,a0
    move.l intbase,a6
    jsr -72(a6)                  ; CloseWindow
unlock_public:
    move.l screen,d0
    beq unlocked
    clr.l screen
    move.l intbase,a6
    ifd AROS68K
    suba.l a0,a0
    else
    lea wbname(pc),a0
    endc
    move.l d0,a1
    jsr -516(a6)
unlocked:
    rts
libraries:
    move.l 4.w,a6
    move.l cgxbase,d0
    bsr close_library
    move.l gfxbase,d0
    bsr close_library
    move.l intbase,d0
    bsr close_library
    move.l dosbase,d0
    bsr close_library
    move.l d7,d0
    bra done
no_cli:
    moveq #20,d0
done:
    movem.l (sp)+,d2-d7/a2-a6
    rts
close_library:
    tst.l d0
    beq close_done
    move.l d0,a1
    jsr -414(a6)
close_done:
    rts
open_controls:
    ; Window.UserPort is at offset 86 on the 68k Intuition ABI.
    move.l a5,screen_tag
    suba.l a0,a0
    lea window_tags,a1
    move.l intbase,a6
    jsr -606(a6)                 ; OpenWindowTagList
    move.l d0,controls
    beq controls_return
    move.l d0,a0
    move.l 86(a0),controls_port
controls_return:
    rts

control_event:
    movem.l d2/a6,-(sp)
    moveq #0,d2
    move.l 4.w,a6
next_control_event:
    move.l controls_port,a0
    jsr -372(a6)                 ; GetMsg
    tst.l d0
    beq control_return
    move.l d0,a1
    move.l 20(a1),d0             ; IntuiMessage.Class
    cmp.l #$200,d0               ; IDCMP_CLOSEWINDOW
    beq control_stop
    cmp.l #$400,d0               ; IDCMP_RAWKEY
    beq control_key
    cmp.l #$40,d0                ; IDCMP_GADGETUP
    bne reply_control
    cmp.w #2,d2
    beq reply_control
    move.l 28(a1),a0             ; IntuiMessage.IAddress
    move.w 38(a0),d2             ; Gadget.GadgetID
    bra reply_control
control_key:
    move.w 24(a1),d0             ; IntuiMessage.Code
    cmp.w #$40,d0                ; Space
    beq control_stop
    cmp.w #2,d2
    beq reply_control
    cmp.w #$44,d0                ; Return
    beq control_record
    cmp.w #$43,d0                ; Keypad Enter
    bne reply_control
control_record:
    moveq #1,d2
    bra reply_control
control_stop:
    moveq #2,d2
reply_control:
    jsr -378(a6)                 ; ReplyMsg
    bra next_control_event
control_return:
    move.l d2,d0
    movem.l (sp)+,d2/a6
    rts

update_budget:
    move.l filename,-(sp)
    jsr video_destination
    addq.l #4,sp
    move.l d0,budget
    move.l d7,-(sp)
    move.l d6,-(sp)
    move.l d0,-(sp)
    pea time_label
    jsr video_estimate
    lea 16(sp),sp
    rts

draw_capacity:
    lea time_label,a1
    moveq #0,d0
capacity_length:
    tst.b (a1)+
    beq capacity_width
    addq.l #1,d0
    bra capacity_length
capacity_width:
    move.l controls,a0
    move.l 50(a0),a1
    lea time_label,a0
    move.l gfxbase,a6
    jsr -54(a6)                  ; TextLength
    moveq #0,d1
    move.w #272,d1
    sub.w d0,d1
    move.w d1,d0
    bpl capacity_position
    moveq #4,d0
capacity_position:
    move.l controls,a0
    move.l 50(a0),a0
    lea capacity_text,a1
    moveq #77,d1
    move.l intbase,a6
    jsr -216(a6)                 ; PrintIText
    rts

rec_volume:
    movem.l d2-d3/a6,-(sp)
    move.l 16(sp),d1
    moveq #-2,d2
    move.l dosbase,a6
    jsr -84(a6)                  ; Lock directory
    tst.l d0
    beq volume_unknown
    move.l d0,d3
    move.l d0,d1
    lea volume_info,a0
    move.l a0,d2
    jsr -114(a6)                 ; Info
    move.l d0,d2
    move.l d3,d1
    jsr -90(a6)                  ; UnLock
    tst.l d2
    beq volume_unknown
    lea volume_info,a0
    cmp.l #82,8(a0)              ; ID_VALIDATED
    bne volume_unknown
    move.l 12(a0),d0
    ble volume_unknown
    tst.l 16(a0)
    bmi volume_unknown
    sub.l 16(a0),d0
    ble volume_unknown
    move.l 20(a0),d1
    ble volume_unknown
    move.l d1,-(sp)
    move.l d0,-(sp)
    jsr video_space
    addq.l #8,sp
    bra volume_return
volume_unknown:
    moveq #0,d0
volume_return:
    movem.l (sp)+,d2-d3/a6
    rts

rec_truncate:
    movem.l d2-d3/a6,-(sp)
    move.l handle,d1
    move.l 16(sp),d2
    moveq #-1,d3
    move.l dosbase,a6
    jsr -456(a6)                 ; SetFileSize
    tst.l d0
    bmi truncate_failed
    move.l handle,d1
    move.l 16(sp),d2
    moveq #-1,d3
    jsr -66(a6)                  ; Seek
    tst.l d0
    bmi truncate_failed
    moveq #1,d0
    bra truncate_return
truncate_failed:
    moveq #0,d0
truncate_return:
    movem.l (sp)+,d2-d3/a6
    rts

rec_alloc:
    move.l a6,-(sp)
    move.l 8(sp),d0
    moveq #0,d1
    move.l 4.w,a6
    jsr -684(a6)                  ; AllocVec
    move.l (sp)+,a6
    rts
rec_free:
    move.l 4(sp),d0
    beq free_return
    move.l a6,-(sp)
    move.l d0,a1
    move.l 4.w,a6
    jsr -690(a6)                  ; FreeVec
    move.l (sp)+,a6
free_return:
    rts
rec_seek:
    movem.l d2-d3/a6,-(sp)
    move.l handle,d1
    move.l 16(sp),d2
    moveq #-1,d3                 ; OFFSET_BEGINNING
    move.l dosbase,a6
    jsr -66(a6)                  ; Seek
    tst.l d0
    spl d0
    and.l #1,d0
    movem.l (sp)+,d2-d3/a6
    rts

rec_write:
    movem.l d2-d3/a6,-(sp)
    move.l handle,d1
    move.l 16(sp),d2
    move.l 20(sp),d3
    move.l dosbase,a6
    jsr -48(a6)
    cmp.l 20(sp),d0
    seq d0
    and.l #1,d0
    movem.l (sp)+,d2-d3/a6
    rts

dosname: dc.b "dos.library",0
intname: dc.b "intuition.library",0
cgxname: dc.b "cybergraphics.library",0
gfxname: dc.b "graphics.library",0
wbname: dc.b "Workbench",0
template: dc.b "FILE/A",0
error: dc.b "Capture failed. Use a new .bmp, .jpg or .png/.mp4 path and a supported screen.",10,0
    even

    section ui,data
window_tags:
    dc.l $80000066,280           ; WA_Width
    dc.l $80000067,96            ; WA_Height
    dc.l $8000006e,window_title  ; WA_Title
    dc.l $80000079               ; WA_PubScreen
screen_tag:
    dc.l 0
    dc.l $8000006c,record_gadget ; WA_Gadgets
    dc.l $8000006a,$640          ; WA_IDCMP
    dc.l $8000006b,$100a         ; WA_Flags
    dc.l 0,0
record_gadget:
    dc.l stop_gadget
    dc.w 12,34,84,20,0,1,1
    dc.l 0,0,record_text,0,0
    dc.w 1
    dc.l 0
stop_gadget:
    dc.l 0
    dc.w 104,34,84,20,0,1,1
    dc.l 0,0,stop_text,0,0
    dc.w 2
    dc.l 0
record_text:
    dc.b 1,0,0,0
    dc.w 6,4
    dc.l 0,record_name,record_hint
stop_text:
    dc.b 1,0,0,0
    dc.w 6,4
    dc.l 0,stop_name,stop_hint
record_hint:
    dc.b 1,0,0,0
    dc.w 6,23
    dc.l 0,enter_name,0
stop_hint:
    dc.b 1,0,0,0
    dc.w 6,23
    dc.l 0,space_name,0
enter_name: dc.b "(Enter)",0
space_name: dc.b "(Space)",0
capacity_text:
    dc.b 1,0,1,0
    dc.w 0,0
    dc.l 0,time_label,0
window_title: dc.b "Easy Screen Recorder",0
record_name: dc.b "Record",0
stop_name: dc.b "Stop",0
    even

    section buffers,bss
dosbase: ds.l 1
intbase: ds.l 1
cgxbase: ds.l 1
gfxbase: ds.l 1
screen: ds.l 1
args: ds.l 1
filename: ds.l 1
handle: ds.l 1
created: ds.w 1
palette: ds.l 768
palcount: ds.w 1
    even
pixels: ds.l 1
format: ds.l 1
budget: ds.l 1
volume_info: ds.l 16
time_label: ds.b 32
controls: ds.l 1
controls_port: ds.l 1
