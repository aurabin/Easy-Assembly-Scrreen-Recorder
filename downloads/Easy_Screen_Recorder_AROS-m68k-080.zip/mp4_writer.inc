/* Motion JPEG in ISO BMFF. Each independently decodable JPEG is one sample.
 * A single chunk starts at byte 36, after ftyp and the mdat header. */
#define VIDEO_FILE_LIMIT 0x7f000000U
#define VIDEO_RESERVE 65536U
#define VIDEO_RATE 5

extern int rec_seek(unsigned long offset);
extern void *rec_alloc(unsigned long);
extern void rec_free(void *);
extern int rec_truncate(unsigned long);
static unsigned *video_sizes;
static unsigned video_capacity, video_budget, video_max_frames;
static int video_limit_hit;

static unsigned video_count, video_bytes;
static int video_ok;
static unsigned char video_buffer[4096];
static unsigned video_used;

static void video_flush(void)
{
    if (video_ok && video_used)
        video_ok = rec_write(video_buffer, video_used);
    video_used = 0;
}

static void video_sink(void *context, void *data, int size)
{
    (void)context;
    const unsigned char *src = data;
    if (!video_ok || video_limit_hit)
        return;
    if ((unsigned)size > video_budget - VIDEO_RESERVE - 4 * (video_count + 1) - video_bytes) {
        video_limit_hit = 1;
        return;
    }
    video_bytes += size;
    while (size && video_ok) {
        unsigned n = sizeof(video_buffer) - video_used;
        if (n > (unsigned)size)
            n = size;
        memcpy(video_buffer + video_used, src, n);
        video_used += n;
        src += n;
        size -= n;
        if (video_used == sizeof(video_buffer))
            video_flush();
    }
}

void video_release(void)
{
    rec_free(video_sizes);
    video_sizes = NULL;
    video_capacity = 0;
}

unsigned video_space(unsigned blocks, unsigned block_size)
{
    if (!block_size)
        return 0;
    return blocks > VIDEO_FILE_LIMIT / block_size ? VIDEO_FILE_LIMIT : blocks * block_size;
}

extern unsigned rec_volume(const char *directory);

unsigned video_destination(const char *path)
{
    char directory[512];
    unsigned end = 0, i;
    for (i = 0; path[i]; ++i) {
        if (i == sizeof(directory) - 1)
            return 0;
        if (path[i] == ':' || path[i] == '/')
            end = i + 1;
    }
    if (!end)
        return rec_volume("");
    memcpy(directory, path, end);
    directory[end] = 0;
    return rec_volume(directory);
}

/* Deliberately overestimate the bytes needed for an individual JPEG. */
unsigned video_frame_limit(unsigned budget, unsigned width, unsigned height)
{
    if (budget <= VIDEO_RESERVE)
        return 0;
    unsigned worst = ((width + 15) & ~15U) * ((height + 15) & ~15U) * 8 + 1028;
    return ((budget - VIDEO_RESERVE) / worst) * 85 / 100;
}

void video_estimate(char *label, unsigned budget, unsigned width, unsigned height)
{
    const char prefix[] = "Max. safe est.: ";
    memcpy(label, prefix, sizeof(prefix) - 1);
    char *out = label + sizeof(prefix) - 1;
    if (!budget) {
        memcpy(out, "unknown", 8);
        return;
    }
    unsigned seconds = video_frame_limit(budget, width, height) / VIDEO_RATE;
    unsigned hours = seconds / 3600;
    unsigned minutes = seconds / 60 % 60;
    seconds %= 60;
    *out++ = '0' + hours / 100;
    *out++ = '0' + hours / 10 % 10;
    *out++ = '0' + hours % 10;
    *out++ = ':';
    *out++ = '0' + minutes / 10;
    *out++ = '0' + minutes % 10;
    *out++ = ':';
    *out++ = '0' + seconds / 10;
    *out++ = '0' + seconds % 10;
    *out = 0;
}

int video_begin(unsigned budget, unsigned width, unsigned height)
{
    static const unsigned char header[] = {
        0,0,0,28,'f','t','y','p','i','s','o','m',0,0,2,0,
        'i','s','o','m','i','s','o','2','m','p','4','1',
        0,0,0,0,'m','d','a','t'
    };
    video_release();
    video_budget = budget < VIDEO_FILE_LIMIT ? budget : VIDEO_FILE_LIMIT;
    video_max_frames = video_frame_limit(video_budget, width, height);
    if (!video_max_frames)
        return 0;
    video_count = video_bytes = video_used = 0;
    video_ok = rec_write(header, sizeof(header));
    return video_ok;
}

int video_frame(const unsigned char *pixels, int width, int height)
{
    if (!video_ok)
        return 0;
    if (video_count >= video_max_frames || video_bytes >= video_budget - VIDEO_RESERVE - 4 * (video_count + 1))
        return 2;
    if (video_count == video_capacity) {
        unsigned capacity = video_capacity ? video_capacity * 2 : 256;
        unsigned *sizes = rec_alloc(capacity * sizeof(*sizes));
        if (!sizes)
            return 2;
        if (video_count)
            memcpy(sizes, video_sizes, video_count * sizeof(*sizes));
        rec_free(video_sizes);
        video_sizes = sizes;
        video_capacity = capacity;
    }
    video_limit_hit = 0;
    unsigned start = video_bytes;
    int ok = stbi_write_jpg_to_func(video_sink, NULL, width, height, 3, pixels, 75);
    video_flush();
    if (!ok || !video_ok || video_limit_hit || start == video_bytes) {
        video_bytes = start;
        video_ok = rec_truncate(36 + start);
        return video_ok ? 2 : 0;
    }
    video_sizes[video_count++] = video_bytes - start;
    return 1;
}

/* The movie metadata is small and emitted in one write. Box lengths are
 * filled after their payloads. Tables describe one chunk of JPEG samples. */
static unsigned char movie[2048];
static unsigned cursor;

static void put8(unsigned value) { movie[cursor++] = value; }
static void put16(unsigned value) { put8(value >> 8); put8(value); }
static void put32(unsigned value) { put16(value >> 16); put16(value); }
static void zeros(unsigned n) { while (n--) put8(0); }
static void bytes(const char *p, unsigned n) { while (n--) put8(*p++); }

static unsigned box(const char *tag)
{
    unsigned start = cursor;
    put32(0);
    bytes(tag, 4);
    return start;
}

static void end_box(unsigned start)
{
    unsigned end = cursor;
    cursor = start;
    put32(end - start);
    cursor = end;
}

static void matrix(void)
{
    for (unsigned i = 0; i < 9; ++i)
        put32(i == 8 ? 0x40000000U : i % 4 == 0 ? 65536 : 0);
}

int video_finish(int width, int height)
{
    if (!video_ok || !video_count)
        return 0;
    cursor = 0;
    put32(video_bytes + 8);
    if (!rec_seek(28) || !rec_write(movie, 4) || !rec_seek(36 + video_bytes))
        return 0;

    cursor = 0;
    unsigned moov = box("moov"), mvhd = box("mvhd");
    zeros(12); put32(VIDEO_RATE); put32(video_count);
    put32(65536); put16(256); zeros(10); matrix(); zeros(24); put32(2);
    end_box(mvhd);
    unsigned trak = box("trak"), tkhd = box("tkhd");
    put32(7); zeros(8); put32(1); zeros(4); put32(video_count);
    zeros(16); matrix(); put32((unsigned)width << 16); put32((unsigned)height << 16);
    end_box(tkhd);
    unsigned mdia = box("mdia"), mdhd = box("mdhd");
    zeros(12); put32(VIDEO_RATE); put32(video_count); put16(0x55c4); put16(0);
    end_box(mdhd);
    unsigned hdlr = box("hdlr");
    zeros(8); bytes("vide", 4); zeros(12); bytes("VideoHandler", 13);
    end_box(hdlr);
    unsigned minf = box("minf"), vmhd = box("vmhd");
    put32(1); zeros(8); end_box(vmhd);
    unsigned dinf = box("dinf"), dref = box("dref");
    put32(0); put32(1);
    unsigned url = box("url "); put32(1); end_box(url);
    end_box(dref); end_box(dinf);
    unsigned stbl = box("stbl"), stsd = box("stsd");
    put32(0); put32(1);
    unsigned sample = box("mp4v");
    zeros(6); put16(1); zeros(16);
    put16(width); put16(height); put32(0x480000); put32(0x480000);
    put32(0); put16(1); zeros(32); put16(24); put16(65535);
    unsigned esds = box("esds");
    put32(0);
    /* MPEG-4 Systems object type 0x6c identifies JPEG video. */
    bytes("\003\025\000\001\000\004\015\154\021", 9);
    zeros(11);
    bytes("\006\001\002", 3);
    end_box(esds); end_box(sample); end_box(stsd);
    unsigned stts = box("stts");
    put32(0); put32(1); put32(video_count); put32(1); end_box(stts);
    unsigned stsc = box("stsc");
    put32(0); put32(1); put32(1); put32(video_count); put32(1); end_box(stsc);
    unsigned stsz = box("stsz");
    put32(0); put32(0); put32(video_count);
    /* Account for the streamed stsz payload in each enclosing box. */
    unsigned sizes_offset = cursor;
    unsigned sizes_bytes = video_count * 4;
    end_box(stsz);
    unsigned stco = box("stco");
    put32(0); put32(1); put32(36); end_box(stco);
    end_box(stbl); end_box(minf); end_box(mdia); end_box(trak); end_box(moov);
    unsigned parents[] = {moov, trak, mdia, minf, stbl, stsz};
    for (unsigned i = 0; i < sizeof(parents) / sizeof(parents[0]); ++i) {
        unsigned offset = parents[i];
        unsigned size = ((unsigned)movie[offset] << 24) |
                        ((unsigned)movie[offset + 1] << 16) |
                        ((unsigned)movie[offset + 2] << 8) | movie[offset + 3];
        cursor = offset;
        put32(size + sizes_bytes);
    }
    if (!rec_write(movie, sizes_offset))
        return 0;
    for (unsigned i = 0; i < video_count;) {
        cursor = 0;
        while (i < video_count && cursor < 1024)
            put32(video_sizes[i++]);
        if (!rec_write(movie, cursor))
            return 0;
    }
    /* Reconstruct stco, since the streaming buffer was reused. */
    cursor = 0;
    unsigned chunk = box("stco");
    put32(0); put32(1); put32(36); end_box(chunk);
    return rec_write(movie, cursor);
}
