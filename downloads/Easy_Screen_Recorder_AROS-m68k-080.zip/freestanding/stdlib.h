#pragma once
#include <stddef.h>
static inline int abs(int n) { return n < 0 ? -n : n; }
