double frexp(double, int *);
