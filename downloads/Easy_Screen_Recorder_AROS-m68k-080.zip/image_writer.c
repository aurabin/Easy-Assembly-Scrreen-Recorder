#include <stddef.h>
#include "freestanding/string.h"

extern void *rec_alloc(unsigned long size);
extern void rec_free(void *ptr);
extern int rec_write(const void *data, int size);

void *memcpy(void *dest, const void *src, size_t size)
{
    unsigned char *d = dest;
    const unsigned char *s = src;
    for (size_t i = 0; i < size; ++i)
        d[i] = s[i];
    return dest;
}

void *memmove(void *dest, const void *src, size_t size)
{
    unsigned char *d = dest;
    const unsigned char *s = src;
    if ((__UINTPTR_TYPE__)d > (__UINTPTR_TYPE__)s &&
        (__UINTPTR_TYPE__)d - (__UINTPTR_TYPE__)s < size) {
        while (size) {
            --size;
            d[size] = s[size];
        }
        return dest;
    }
    return memcpy(dest, src, size);
}

void *memset(void *dest, int value, size_t size)
{
    unsigned char *d = dest;
    for (size_t i = 0; i < size; ++i)
        d[i] = value;
    return dest;
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) {
        ++a;
        ++b;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

/* Stored DEFLATE blocks keep peak encoder memory predictable and avoid
 * compression tables on machines with limited RAM. PNG remains lossless. */
static unsigned char *stored_zlib(unsigned char *data, int length, int *size, int quality)
{
    (void)quality;
    unsigned char *output = rec_alloc(length + 6 + ((length + 65534) / 65535) * 5);
    if (!output)
        return NULL;
    unsigned char *p = output;
    *p++ = 0x78;
    *p++ = 0x01;
    unsigned a = 1, b = 0;
    while (length) {
        unsigned n = length > 65535 ? 65535 : (unsigned)length;
        length -= n;
        *p++ = length == 0;
        *p++ = n;
        *p++ = n >> 8;
        *p++ = ~n;
        *p++ = ~n >> 8;
        while (n--) {
            unsigned value = *data++;
            *p++ = value;
            a += value;
            if (a >= 65521)
                a -= 65521;
            b += a;
            if (b >= 65521)
                b -= 65521;
        }
    }
    *p++ = b >> 8;
    *p++ = b;
    *p++ = a >> 8;
    *p++ = a;
    *size = p - output;
    return output;
}

#define STB_IMAGE_WRITE_IMPLEMENTATION
#define STB_IMAGE_WRITE_STATIC
#define STBI_WRITE_NO_STDIO
#define STBIW_ASSERT(x) ((void)0)
#define STBIW_MALLOC(size) rec_alloc(size)
#define STBIW_REALLOC(p, size) ((void *)0)
#define STBIW_FREE(p) rec_free(p)
#define STBIW_ZLIB_COMPRESS stored_zlib
#include "stb_image_write.h"

static void write_chunk(void *context, void *data, int size)
{
    int *ok = context;
    if (*ok && !rec_write(data, size))
        *ok = 0;
}

static int equal_extension(const char *name, const char *format)
{
    while (*name && *format) {
        char ch = *name++;
        if (ch >= 'A' && ch <= 'Z')
            ch += 'a' - 'A';
        if (ch != *format++)
            return 0;
    }
    return !*name && !*format;
}

int image_format(const char *name)
{
    const char *extension = "";
    for (; *name; ++name) {
        if (*name == '/' || *name == ':')
            extension = "";
        else if (*name == '.')
            extension = name + 1;
    }
    if (equal_extension(extension, "bmp"))
        return 1;
    if (equal_extension(extension, "jpg") || equal_extension(extension, "jpeg"))
        return 2;
    if (equal_extension(extension, "png"))
        return 3;
    return equal_extension(extension, "mp4") ? 4 : 0;
}

int encode_image(const unsigned char *pixels, int width, int height, int format)
{
    int ok = 1, encoded = 0;
    switch (format) {
    case 1:
        encoded = stbi_write_bmp_to_func(write_chunk, &ok, width, height, 3, pixels);
        break;
    case 2:
        encoded = stbi_write_jpg_to_func(write_chunk, &ok, width, height, 3, pixels, 90);
        break;
    case 3:
        stbi_write_force_png_filter = 0;
        encoded = stbi_write_png_to_func(write_chunk, &ok, width, height, 3, pixels, width * 3);
        break;
    }
    return encoded && ok;
}

#include "mp4_writer.inc"
