#include <intuition/screens.h>
#include <graphics/displayinfo.h>
#include <cybergraphx/cybergraphics.h>
#ifdef __cplusplus
extern "C" {
#endif
#include <proto/exec.h>
#include <proto/dos.h>
#include <proto/intuition.h>
#include <proto/graphics.h>
#include <proto/cybergraphics.h>
#ifdef __cplusplus
}
#endif

#define MAX_WIDTH 4096

struct ExecBase *SysBase;
struct DosLibrary *DOSBase;
struct IntuitionBase *IntuitionBase;
struct GfxBase *GfxBase;
struct Library *CyberGfxBase;
static ULONG palette[256 * 3];
static BPTR image_file;
static char time_label[32];
static struct IntuiText time_text;

static void show_capacity(struct Window *window)
{
    time_text.FrontPen = 1;
    time_text.DrawMode = 1;     /* JAM2 */
    time_text.IText = (UBYTE *)time_label;
    unsigned len = 0;
    while (time_label[len])
        ++len;
    WORD x = window->Width - window->BorderRight - TextLength(window->RPort, (CONST_STRPTR)time_label, len) - 4;
    PrintIText(window->RPort, &time_text, x > 4 ? x : 4,
               window->Height - window->BorderBottom - window->RPort->TxHeight - 2);
}

/* Gadgets are owned by this Shell process for the lifetime of the window. */
static struct Window *open_controls(struct Screen *screen)
{
    static struct IntuiText labels[4];
    static struct Gadget buttons[2];
    labels[0].IText = (UBYTE *)"Record";
    labels[1].IText = (UBYTE *)"Stop";
    labels[2].IText = (UBYTE *)"(Enter)";
    labels[3].IText = (UBYTE *)"(Space)";
    for (unsigned i = 0; i < 2; ++i) {
        labels[i].NextText = &labels[i + 2];
        labels[i + 2].FrontPen = 1;
        labels[i + 2].LeftEdge = 6;
        labels[i + 2].TopEdge = screen->Font->ta_YSize + 8;
        labels[i].FrontPen = 1;
        labels[i].LeftEdge = 6;
        labels[i].TopEdge = 3;
        buttons[i].LeftEdge = 12 + 92 * i;
        buttons[i].TopEdge = screen->WBorTop + screen->Font->ta_YSize + 4;
        buttons[i].Width = 84;
        buttons[i].Height = screen->Font->ta_YSize + 6;
        buttons[i].Activation = GACT_RELVERIFY;
        buttons[i].GadgetType = GTYP_BOOLGADGET;
        buttons[i].GadgetText = &labels[i];
        buttons[i].GadgetID = i + 1;
    }
    buttons[0].NextGadget = &buttons[1];
    struct TagItem tags[] = {
        {WA_Width, 280}, {WA_Height, (IPTR)(buttons[0].TopEdge + buttons[0].Height + screen->Font->ta_YSize * 2 + 14)},
        {WA_Title, (IPTR)"Easy Screen Recorder"},
        {WA_PubScreen, (IPTR)screen}, {WA_Gadgets, (IPTR)buttons},
        {WA_IDCMP, IDCMP_GADGETUP | IDCMP_CLOSEWINDOW | IDCMP_RAWKEY},
        {WA_Flags, WFLG_DRAGBAR | WFLG_CLOSEGADGET | WFLG_ACTIVATE | WFLG_SMART_REFRESH},
        {TAG_DONE, 0}
    };
    return OpenWindowTagList(NULL, tags);
}

/* Return 1 for Record, 2 for Stop or close, and zero for no action. */
static unsigned control_event(struct Window *window)
{
    struct IntuiMessage *msg;
    unsigned action = 0;
    while ((msg = (struct IntuiMessage *)GetMsg(window->UserPort))) {
        if (msg->Class == IDCMP_CLOSEWINDOW)
            action = 2;
        else if (msg->Class == IDCMP_GADGETUP && action != 2)
            action = ((struct Gadget *)msg->IAddress)->GadgetID;
        else if (msg->Class == IDCMP_RAWKEY) {
            if (msg->Code == 0x40)           /* Space */
                action = 2;
            else if (action != 2 && (msg->Code == 0x44 || msg->Code == 0x43))
                action = 1;                 /* Return or keypad Enter */
        }
        ReplyMsg(&msg->ExecMessage);
    }
    return action;
}

#ifdef __cplusplus
extern "C" {
#endif
int image_format(const char *name);
int encode_image(const unsigned char *pixels, int width, int height, int format);
int video_begin(unsigned, unsigned, unsigned);
unsigned video_destination(const char *);
unsigned video_space(unsigned, unsigned);
void video_estimate(char *, unsigned, unsigned, unsigned);
void video_release(void);
int rec_truncate(unsigned long offset)
{
    return SetFileSize(image_file, offset, OFFSET_BEGINNING) >= 0 &&
           Seek(image_file, offset, OFFSET_BEGINNING) >= 0;
}
unsigned rec_volume(const char *directory)
{
    struct InfoData info;
    BPTR lock = Lock((CONST_STRPTR)directory, ACCESS_READ);
    if (!lock)
        return 0;
    BOOL ok = Info(lock, &info);
    UnLock(lock);
    if (!ok || info.id_DiskState != ID_VALIDATED || info.id_NumBlocksUsed >= info.id_NumBlocks || info.id_BytesPerBlock <= 0)
        return 0;
    UQUAD blocks = info.id_NumBlocks - info.id_NumBlocksUsed;
    return video_space(blocks > 0x7fffffffU ? 0x7fffffffU : (unsigned)blocks, info.id_BytesPerBlock);
}
int video_frame(const unsigned char *pixels, int width, int height);
int video_finish(int width, int height);
int rec_seek(unsigned long offset)
{
    return Seek(image_file, offset, OFFSET_BEGINNING) >= 0;
}
void *rec_alloc(unsigned long size) { return AllocVec(size, 0); }
void rec_free(void *ptr) { if (ptr) FreeVec(ptr); }
int rec_write(const void *data, int size)
{
    return Write(image_file, data, size) == size;
}
#ifdef __cplusplus
}
#endif

class ImageBuffer {
public:
    ImageBuffer() = default;
    ~ImageBuffer() { rec_free(data); }
    ImageBuffer(const ImageBuffer &) = delete;
    ImageBuffer &operator=(const ImageBuffer &) = delete;

    UBYTE *data = nullptr;
};

extern "C" __attribute__((section(".text.entry"))) LONG recorder_entry(STRPTR command, ULONG length, struct ExecBase *base)
{
    (void)command;
    (void)length;
    SysBase = base;
    DOSBase = (struct DosLibrary *)OpenLibrary((CONST_STRPTR)"dos.library", 39);
    if (!DOSBase)
        return 20;
    LONG result = 20;
    SIPTR filename = 0;
    struct RDArgs *args = NULL;
    struct Screen *screen = NULL;
    struct Window *controls = NULL;
    BPTR output = 0;
    ImageBuffer pixels;
    int format = 0;
    unsigned budget = 0;
    struct RastPort *rp = NULL;
    LONG width = 0, height = 0;
    ULONG count = 0, depth = 0;
    BPTR existing = 0;
    if (!Cli())
        goto cleanup;
    args = ReadArgs((CONST_STRPTR)"FILE/A", &filename, NULL);
    if (!args)
        goto cleanup;
    format = image_format((const char *)filename);
    if (!format)
        goto cleanup;
    IntuitionBase = (struct IntuitionBase *)OpenLibrary((CONST_STRPTR)"intuition.library", 39);
    GfxBase = (struct GfxBase *)OpenLibrary((CONST_STRPTR)"graphics.library", 39);
    if (!IntuitionBase || !GfxBase)
        goto cleanup;

    Delay(150);
    screen = LockPubScreen(NULL);
    if (!screen)
        goto cleanup;
    rp = &screen->RastPort;
    width = screen->Width;
    height = screen->Height;
    if (width <= 0 || width > MAX_WIDTH || height <= 0 || height > 4096 || !rp->BitMap)
        goto cleanup;
    depth = GetBitMapAttr(rp->BitMap, BMA_DEPTH);
    if (!depth)
        goto cleanup;
    if (depth > 8) {
        CyberGfxBase = OpenLibrary((CONST_STRPTR)"cybergraphics.library", 0);
        if (!CyberGfxBase)
            goto cleanup;
    } else {
        ULONG mode = GetVPModeID(&screen->ViewPort);
        struct ColorMap *cm = screen->ViewPort.ColorMap;
        if (mode == (ULONG)INVALID_ID || (mode & 0x880) || !cm)
            goto cleanup;
        count = cm->Count;
        if (!count || count > 256)
            goto cleanup;
        GetRGB32(cm, 0, count, palette);
    }

    if (format == 4) {
        budget = video_destination((const char *)filename);
        video_estimate(time_label, budget, width, height);
        controls = open_controls(screen);
        if (!controls)
            goto cleanup;
        show_capacity(controls);
        for (;;) {
            WaitPort(controls->UserPort);
            unsigned action = control_event(controls);
            if (action == 2) {
                result = 0;
                goto cleanup;
            }
            if (action == 1) {
                budget = video_destination((const char *)filename);
                break;
            }
        }
    }
    existing = Lock((CONST_STRPTR)filename, ACCESS_READ);
    if (existing) {
        UnLock(existing);
        goto cleanup;
    }
    if (IoErr() != ERROR_OBJECT_NOT_FOUND)
        goto cleanup;
    output = Open((CONST_STRPTR)filename, MODE_NEWFILE);
    if (!output)
        goto cleanup;
    pixels.data = static_cast<UBYTE *>(rec_alloc(width * height * 3));
    if (!pixels.data)
        goto cleanup;
    image_file = output;
    if (format == 4 && !video_begin(budget, width, height))
        goto cleanup;
    for (unsigned frame = 0; frame < (format == 4 ? ~0U : 1U); ++frame) {
        if (frame) {
            Delay(10);
            if (control_event(controls) == 2)
                break;
        }
        for (LONG y = 0; y < height; ++y) {
            UBYTE *line = pixels.data + y * width * 3;
            if (CyberGfxBase) {
                if (ReadPixelArray(line, 0, 0, width * 3, rp, 0, y,
                                   width, 1, RECTFMT_RGB) != (ULONG)width)
                    goto cleanup;
            } else {
                for (LONG x = 0; x < width; ++x) {
                    LONG pen = ReadPixel(rp, x, y);
                    if (pen < 0 || (ULONG)pen >= count)
                        goto cleanup;
                    for (unsigned c = 0; c < 3; ++c)
                        line[x * 3 + c] = palette[pen * 3 + c] >> 24;
                }
            }
        }
        if (format == 4) {
            int frame_status = video_frame(pixels.data, width, height);
            if (frame_status == 2)
                break;
            if (!frame_status)
                goto cleanup;
        }
    }
    if (controls) {
        CloseWindow(controls);
        controls = NULL;
    }
    UnlockPubScreen(NULL, screen);
    screen = NULL;
    if (format == 4 ? video_finish(width, height) :
                      encode_image(pixels.data, width, height, format))
        result = 0;

cleanup:
    video_release();
    if (output) {
        if (!Close(output))
            result = 20;
        if (result)
            DeleteFile((CONST_STRPTR)filename);
    }
    if (CyberGfxBase)
        CloseLibrary(CyberGfxBase);
    if (controls)
        CloseWindow(controls);
    if (screen)
        UnlockPubScreen(NULL, screen);
    if (GfxBase)
        CloseLibrary((struct Library *)GfxBase);
    if (IntuitionBase)
        CloseLibrary((struct Library *)IntuitionBase);
    if (args)
        FreeArgs(args);
    if (result && Cli())
        PutStr((CONST_STRPTR)"Capture failed. Use a new .bmp, .jpg or .png/.mp4 path and a supported screen.\n");
    CloseLibrary((struct Library *)DOSBase);
    return result;
}
