#!/bin/sh
set -eu
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
for target in AmigaOS39-040 AmigaOS39-060 Apollo-Vampire-080 AROS-m68k-080; do
    case "$target" in
        *-040) cpu=68040 ;;
        *-060) cpu=68060 ;;
        *-080) cpu=68080 ;;
    esac
    case "$target" in
        AROS-*) set -- -DAROS68K=1 ;;
        *) set -- ;;
    esac
    case "$cpu" in
        68040) encoder_cpu=040 ;;
        *) encoder_cpu=060 ;;
    esac
    "${VASM:-vasmm68k_mot}" -quiet -m"$cpu" "$@" -Felf -o "$tmp/capture.o" EasyScreenRecorder.s
    "${M68K_AS:-m68k-linux-gnu-as}" -m68"$encoder_cpu" -o "$tmp/encoder.o" "image_writer-$encoder_cpu.s"
    "${VLINK:-vlink}" -bamigahunk -o "EasyScreenRecorder-$target" "$tmp/capture.o" "$tmp/encoder.o"
    chmod +x "EasyScreenRecorder-$target"
done
